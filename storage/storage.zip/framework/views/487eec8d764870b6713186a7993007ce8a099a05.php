<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Home - Proudct</title>
    <meta charset="UTF-8">
    <meta name="description" content="Cassi Photo Studio HTML Template">
    <meta name="keywords" content="photo, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Stylesheets -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/bootstrap.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/font-awesome.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/elegant-icons.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/owl.carousel.min.css')); ?>"/>
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />


    <!-- Main Stylesheets -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/sass/style.css')); ?>"/>

    <!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>

<body>
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <!-- Offcanvas Menu Section -->
    <div class="offcanvas-menu-wrapper">
        <div class="menu-header" style="color: white;">
            <a href="<?php echo e(url('/')); ?>" class="site-logo">
                <img src="<?php echo e(url('frontend/img/logo.png')); ?>" alt="">
            </a>
            <div class="menu-switch" id="menu-canvas-close">
                <i class="icon_close"></i>
            </div>
        </div>
        <ul class="main-menu">
            <li><a href="<?php echo e(url('/')); ?>" class="active">Home</a></li>
            <li><a href="<?php echo e(url('/ourwork')); ?>">Our Work</a></li>
            <li><a href="<?php echo e(url('/about')); ?>">About</a></li>
            <li><a href="<?php echo e(url('/blog')); ?>">Blog</a></li>
        </ul>
        <div class="menu-footer">
            <div class="footer-social">
                <a href="#">Facebook</a>
                <a href="https://wa.me/6285726908787?text=Hi%20can%20I%20look%20your%20pricelist">Whatsapp</a>
                <a href=" #">Instagram</a>
                <a href="#">Studio</a>
            </div>
            <div class="copyright">
                <p>
                    Copyright &copy;<script>
                        document.write(new Date().getFullYear());

                    </script> All rights reserved Show Me Your Wish Production
                </p>
            </div>
        </div>
    </div>
    <!-- Offcanvas Menu Section end -->

    <!-- Header section -->
    <header id="header" class="header-section headroom header--fixed" style="background-color: #0d2237;">
     
        <a href="<?php echo e(url('/')); ?>" class="site-logo">
            <img src="<?php echo e(url('frontend/img/logo.png')); ?>" alt="">
        </a>
        <div class="menu-switch" id="menu-canvas-show">
            <i class="icon_menu"></i>
        </div>
        
    </header>
    <!-- Header section end -->

    <!-- Hero section -->
    <section class="hero-section" style="padding-top: 80px;">
        <div class="hero-slider owl-carousel">
            <?php if($promotions): ?> 
                <?php $__currentLoopData = $promotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promotion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                
                <div class="hero-item">
                    <div class="hero-text" data-aos="zoom-in">
                        <!-- <div class="ht-cata">Nature</div> -->
                        <h2><?php echo e($promotion->title); ?></h2>
                        <p><?php echo e($promotion->summary); ?></p>
                        <a href="<?php echo e(url('event/'.$promotion->slug)); ?>" class="btn btn-outline-light btn-lg">More Info<i class="arrow_right"></i></a>
                        <a href="<?php echo e($promotion->link); ?>" target="_blank" class="btn btn-outline-warning btn-lg ml-4">ORDER NOW</a>
                    </div>
                    <div class="hi-bg set-bg" data-setbg="<?php echo e(Storage::url($promotion->image)); ?>"></div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>             
            <div class="hero-item">
                <div class="hero-text">
                    <!-- <div class="ht-cata">Nature</div> -->
                    <h2><?php echo e($banner->title); ?></h2>
                    <p><?php echo e($banner->summary); ?></p>
                    <a href="#" class="ht-btn">See More <i class="arrow_right"></i></a>
                </div>
                <div class="hi-bg set-bg" data-setbg="<?php echo e(Storage::url($banner->image)); ?>"></div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    <!-- Hero section end -->

    <!-- Hero section -->
    <section class="spec-section col-sm-12" style="padding-top: 80px;">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6 col-sm-12 p-0 text-center">
                    <figure class="figure" data-aos="zoom-in-right">
                        <img src="<?php echo e(url('frontend/img/360.png')); ?>" class="figure-img img-fluids" style="max-height: 100px;">
                        <figcaption class="figure-caption text-center">
                            <p>Give your customers the whole picture with 360 photos. Interactive and engaging, 360
                                photos let shoppers
                                rotate, pause, even zoom in on a product image for a closer look—and help boost their
                                confidence in their
                                online purchase.</p>
                        </figcaption>
                    </figure>
                </div>
                <div class="col-lg-6 col-sm-12 p-0 text-center">
                    <figure class="figure" data-aos="zoom-in-left">
                        <img src="<?php echo e(url('frontend/img/printer.png')); ?>" class="figure-img img-fluids" style="max-height: 100px;">
                        <figcaption class="figure-caption text-center">
                            <p>Multiple image sizes are delivered with each photo whether you intend to use
                                them on the
                                web or in high
                                quality prints.</p>
                        </figcaption>
                    </figure>
                </div>
                <div class="col-lg-6 col-sm-12 p-0 text-center">
                    <figure class="figure" data-aos="zoom-in-right">
                        <img src="<?php echo e(url('frontend/img/ecommerce1.png')); ?>" class="figure-img img-fluids" style="max-height: 100px;">
                        <figcaption class="figure-caption text-center">
                            <p>Our photos integrate seamlessly with popular platforms such as Tokopedia, Shopee,
                                Bukalapak, Lazada, etc.</p>
                        </figcaption>
                    </figure>
                </div>
                <div class="col-lg-6 col-sm-12 p-0 text-center">
                    <figure class="figure" data-aos="zoom-in-left">
                        <img src="<?php echo e(url('frontend/img/instagram.svg')); ?>" class="figure-img img-fluids" style="max-height: 100px;">
                        <figcaption class="figure-caption text-center">
                            <p>Our photos optimized for social media feeds such as Instagram.</p>
                        </figcaption>
                    </figure>
                </div>
            </div>
        </div>   
    </section>
    <!-- Hero section end -->

    <!-- Team section -->
    <section class="latest-work mt-5">
        <div class="container-fluid">
            <div class="text-center mb-5" style="color: #fad02c;">
                <h2>Latest Work</h2>
            </div>
            <div class="row justify-content-center">
                <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-2 col-md-4 col-sm-12 p-0">
                    <div class="product-item" data-aos="zoom-in">
                        <img src="<?php echo e(Storage::url($p->display->image)); ?>" alt="">
                        <div class="product-meta">
                            <div class="prod-text">
                                <h5><?php echo e($p->name); ?></h5>
                                <div class="prod-social">
                                    <a href="<?php echo e(route('gallery',$p->slug)); ?>" class="btn btn-dark">View More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- Team section end -->


    <!-- Footer section -->
    <footer class="footer-section" style="padding-bottom: 0px;">
        <div class="footer-social">
            <a href="#">Facebook</a>
            <a href="https://wa.me/6285726908787?text=Hi%20can%20I%20look%20your%20pricelist">Whatsapp</a>
            <a href="#">Instagram</a>
            <a href="#">Studio</a>
        </div>
        <div class="copyright">
            <p>
                Copyright &copy;<script>
                    document.write(new Date().getFullYear());

                </script> Show Me Your Wish Production, All rights reserved.
            </p>
        </div>
    </footer>
    <!-- Footer section end -->

    <!--====== Javascripts & Jquery ======-->
    <script src="<?php echo e(asset('frontend/js/vendor/jquery-3.2.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/masonry.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/main.js')); ?>"></script>
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>
    <script src="https://unpkg.com/headroom.js@0.11.0/dist/headroom.min.js"></script>
    <script>
        (function ($) {
            "use strict";
            // headroom js activation
            var myElement = document.querySelector("header");
            // construct an instance of Headroom, passing the element
            var headroom = new Headroom(myElement);
            // initialise
            headroom.init();
        }(jQuery));
    </script>
</body>

</html>
<?php /**PATH D:\web\proudct\resources\views/pages/home.blade.php ENDPATH**/ ?>