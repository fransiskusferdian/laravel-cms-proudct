

<?php $__env->startPush('after-style'); ?>
     <link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/dataTables.bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('alert'); ?>

<?php $__env->stopPush(); ?>

 

<?php $__env->startSection('content'); ?>

<?php if(Session::has('success')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(Session::get('success')); ?>

     </div>
<?php elseif(Session::has('danger')): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e(Session::get('danger')); ?>

     </div> 
<?php endif; ?>
            <!-- Animated -->
                 <div class="animated fadeIn">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <strong class="card-title">Sub-Category</strong>
                                <a href="" class="btn btn-primary mb-3" data-toggle="modal" data-target="#newSubCategoryModal">+ New Category</a>
                            </div>
                            <div class="card-body">
                                <table id="table" class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Category</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></td>
                                            <td value="<?php echo e($item->category_id); ?>"><?php echo e($item->category_id); ?></td>
                                            <td>
                                               <a href="" data-href="<?php echo e(route('updatesubcategory',$item->id)); ?>" data-value="<?php echo e($item->name); ?>" class="btn btn-info"  data-toggle="modal"
                                                   data-target="#updateSubcategoryModal">
                                                    <i class="fa fa-pencil"></i>
                                                </a>
                                                <a href="" data-href="<?php echo e(route('destroysubcategory',$item->id)); ?>" class="btn btn-danger" data-toggle="modal"
                                                   data-target="#deleteSubCategoryModal"><i class="fa fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                 <!-- Delete Image Modal-->
                <div class="modal fade" id="deleteSubCategoryModal" tabindex="-1" role="dialog"
                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            
                                <div class="modal-header d-flex align-item-start">
                                    <h5 class="modal-title" id="exampleModalLabel">Delete Sub-Category</h5>
                                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                                <div class="modal-body">You can rename it instead of delete this Sub-category</div>
                                <div class="modal-footer">
                                    <form action="" method="post" id="deletesubcategory">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                    <button class="btn btn-primary" type="submit">Delete</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- End Delete Image Modal-->
                </div>

                 <!-- New Sub-Category Modal-->
                <div class="modal fade" id="newSubCategoryModal" tabindex="-1" role="dialog"
                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <form action="<?php echo e(route('storesubcategory')); ?>" method="post" id="newSubcategory">
                                <?php echo csrf_field(); ?>
                                <div class="modal-header d-flex align-item-start">
                                    <h5 class="modal-title" id="exampleModalLabel">New Sub-Category</h5>
                                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                                 <div class="modal-body">
                                      <div class="form-group">
                                            <select name="category_id" class="form-control">
                                                <option value="">Please select</option>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                     <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                     </div>
                                     <div class="form-group">
                                        <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="category" value="<?php echo e(old('name')); ?>" name="name" placeholder="Sub-Category name">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                     </div>
                                </div>
                                 <div class="modal-footer">
                                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                      <button type="submit" class="btn btn-primary">Submit</button>
                                  </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- End Delete Image Modal-->

                    <!-- Update Category Modal-->
                <div class="modal fade" id="updateSubcategoryModal" tabindex="-1" role="dialog"
                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <form action="" method="post" id="updatesubcategory">
                                <?php echo method_field('put'); ?>
                                <?php echo csrf_field(); ?>
                                <div class="modal-header d-flex align-item-start">
                                    <h5 class="modal-title" id="exampleModalLabel">Rename Category</h5>
                                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                                 <div class="modal-body">
                                      <div class="form-group">
                                            <select name="category_id" class="form-control">
                                                <option value="">Please select</option>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                     <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                     </div>
                                     <div class="form-group">
                                        <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="subcategory" value="<?php echo e(old('name')); ?>" name="name" placeholder="category name">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                     </div>
                                </div>
                                 <div class="modal-footer">
                                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                      <button type="submit" class="btn btn-primary">Submit</button>
                                  </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- End Update Category Modal-->
            </div>
            <!-- .animated -->
       
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>
    
    <script src="<?php echo e(asset('backend/assets/js/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/js/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
    <script>
        $(document).ready(function() {
         $('#table').DataTable();
     });
    </script>
    <script>
        $('#deleteSubCategoryModal').on('show.bs.modal', function (e) {
            $(this).find('#deletesubcategory').attr('action', $(e.relatedTarget).data('href'));
        });
    </script>

     <script>
        $('#updateSubcategoryModal').on('show.bs.modal', function (e) {
            $(this).find('#updatesubcategory').attr('action', $(e.relatedTarget).data('href'));
            $(this).find('#subcategory').attr('value', $(e.relatedTarget).data('value'));
        });
    </script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web\proudct\resources\views/pages/admin/category/subcategory.blade.php ENDPATH**/ ?>