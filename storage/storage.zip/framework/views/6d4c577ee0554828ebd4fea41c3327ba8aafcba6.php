

<?php $__env->startPush('after-style'); ?>
    <style>
          .img-wrap {
            position: relative;
            display: inline-block;
        }

        .img-wrap .close {
            position: absolute;
            top: 2px;
            right: 2px;
            z-index: 100;
            background-color: #FFF;
            padding: 5px 5px 5px;
            color: #000;
            font-weight: bold;
            cursor: pointer;
            opacity: .2;
            text-align: center;
            font-size: 18px;
            line-height: 10px;
            border-radius: 50%;
        }

        .img-wrap:hover .close {
            opacity: 1;
        }

    </style>    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<?php if(Session::has('success')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(Session::get('success')); ?>

     </div>
<?php elseif(Session::has('danger')): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e(Session::get('danger')); ?>

     </div> 
<?php endif; ?>
       <!-- Animated -->
            <div class="animated fadeIn gallery-section">
                <div class="row mb-5">
                    <div class="col">
                        <a href="" data-toggle="modal" data-target="#addImagesModal" class="btn btn-primary">Add
                            Image/s</a>
                    </div>
                </div>

                <div class="row gallery-grid justify-content-center">
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-3 col-sm-6 gallery-item mt-3">
                        <div class="img-wrap">
                            <a href="" data-href="<?php echo e(route('delete',$item->id)); ?>" 
                                style="text-decoration : none; color : inherit;" data-toggle="modal"
                                data-target="#deleteImageModal"><span class="close">X<i
                                        class="far fa-trash-alt"></i></span>
                            </a>
                            <img src="<?php echo e(Storage::url($item->image)); ?>" alt="">
                        </div>
                    </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>    
               

                <!--Add Images Modal -->
                <div class="modal fade" id="addImagesModal" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                         <div class="modal-header d-flex align-item-start">
                              <h4 class="Add Images" id="staticBackdropLabel">Add Images</h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                              </button>
                         </div>
                       <form action="<?php echo e(route('addimages', $directory)); ?>" enctype="multipart/form-data" method="post" accept-charset="utf-8">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                       <div class="modal-body">
                            <div class="row">
                                <div class="col">
                                    <div class=" form-group row">
                                        <div class="col-sm-12">
                                            <h5>Images</h5>
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input" id="images" name="images[]" multiple>
                                                
                                                <label class="custom-file-label" for="images">Choose files</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                             </div>
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                        </form>
                    </div>
                  </div>
                </div>
                 <!-- End Add Images -->


                <!-- Delete Image Modal-->
                <div class="modal fade" id="deleteImageModal" tabindex="-1" role="dialog"
                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <form action="" method="post" id="deleteimage">
                                <div class="modal-header d-flex align-item-start">
                                    <h5 class="modal-title" id="exampleModalLabel">Are you sure to delete this Image?</h5>
                                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                                <div class="modal-body">Are you sure want to delete this image?</div>
                                <div class="modal-footer">
                                    <?php echo method_field('delete'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                    <button class="btn btn-primary" type="submit">Delete</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- End Delete Image Modal-->
            </div>    

<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>
      <script>
        $('#deleteImageModal').on('show.bs.modal', function (e) {
            $(this).find('#deleteimage').attr('action', $(e.relatedTarget).data('href'));
        });
      </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web\proudct\resources\views/pages/admin/portfolio/gallery.blade.php ENDPATH**/ ?>