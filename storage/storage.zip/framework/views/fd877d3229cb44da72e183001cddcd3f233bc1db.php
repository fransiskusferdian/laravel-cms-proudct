<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Proudct - Blog</title>
    <meta charset="UTF-8">
    <meta name="description" content="Cassi Photo Studio HTML Template">
    <meta name="keywords" content="photo, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Stylesheets -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/font-awesome.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/elegant-icons.css')); ?>" />

    <!-- Main Stylesheets -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/sass/style.css')); ?>" />
    <!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
</head>

<body>
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <!-- Offcanvas Menu Section -->
    <div class="offcanvas-menu-wrapper">
        <div class="menu-header">
            <a href="<?php echo e(url('/')); ?>" class="site-logo">
                <img src="<?php echo e(url('frontend/img/logo.png')); ?>" alt="">
            </a>
            <div class="menu-switch" id="menu-canvas-close">
                <i class="icon_close"></i>
            </div>
        </div>
        <ul class="main-menu">
            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
            <li><a href="<?php echo e(url('/ourwork')); ?>">Our Work</a></li>
            <li><a href="<?php echo e(url('/about')); ?>">About</a></li>
            <li><a href="<?php echo e(url('/blog')); ?>" class="active">Blog</a></li>
        </ul>
        <div class="menu-footer">
            <div class="footer-social">
                <a href="#">Facebook</a>
                <a href="https://wa.me/6285726908787?text=Hi%20can%20I%20look%20your%20pricelist">Whatsapp</a>
                <a href="#">Instagram</a>
                <a href="#">Studio</a>
            </div>
            <div class="copyright">
                <p>
                    Copyright &copy;<script>
                        document.write(new Date().getFullYear());

                    </script> All rights reserved Show Me Your Wish Production
                </p>
            </div>
        </div>
    </div>
    <!-- Offcanvas Menu Section end -->

    <!-- Header section -->
    <header id="header" class="header-section headroom header--fixed" style="background-color: #0d2237;">
        <a href="<?php echo e(url('/')); ?>" class="site-logo">
            <img src="<?php echo e(url('frontend/img/logo.png')); ?>" alt="">
        </a>
        <div class="menu-switch" id="menu-canvas-show">
            <i class="icon_menu"></i>
        </div>
    </header>
    <!-- Header section end -->

    <section class="blog-section">
        
        
            <div class="text-center" style="margin-top: 95px;">
                <h2 style="color: white" class="mb-4">Blog</h2>
                <a href="<?php echo e(url('/blog')); ?>" class="<?php if($selectedtag == 'all'): ?> active <?php endif; ?> btn btn-outline-warning" >All</a>
                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>            
                    <a href="<?php echo e(url('blog/tag',$tag->slug)); ?>" class=" <?php if($selectedtag == $tag->slug): ?> active <?php endif; ?> btn btn-outline-warning"><?php echo e($tag->name); ?>  </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        
            <div class="blog-post-items mt-4">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="blog-col" id="posts">
                    <div class="blog-item set-bg" data-setbg="<?php echo e($post->featured_image); ?>">
                        <div class="blog-text">
                            <div class="bi-cata"><?php echo e($post->tags['0']['name']); ?></div>
                            <h6><a href="<?php echo e(route('blog.show', $post->slug)); ?>"><?php echo e($post->summary); ?></a></h6>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="d-flex justify-content-center mt-5">
                <?php echo e($posts->links()); ?>

            </div>
       
    </section>  
    <!-- Footer section -->
    <footer class="footer-section" style="padding-bottom: 0px;">
        <div class="footer-social">
            <a href="#">Facebook</a>
            <a href="https://wa.me/6285726908787?text=Hi%20can%20I%20look%20your%20pricelist">Whatsapp</a>
            <a href=" #">Instagram</a>
            <a href="#">Studio</a>
        </div>
        <div class="copyright">
            <p>
                Copyright &copy;<script>
                    document.write(new Date().getFullYear());

                </script> All rights reserved Show Me Your Wish Production
            </p>
        </div>
    </footer>
    <!-- Footer section end -->

    <!--====== Javascripts & Jquery ======-->
    <script src="<?php echo e(asset('frontend/js/vendor/jquery-3.2.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/masonry.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/main.js')); ?>"></script>
    <script src="https://unpkg.com/headroom.js@0.11.0/dist/headroom.min.js"></script>
    <script>
        (function ($) {
            "use strict";
            // headroom js activation
            var myElement = document.querySelector("header");
            // construct an instance of Headroom, passing the element
            var headroom = new Headroom(myElement);
            // initialise
            headroom.init();
        }(jQuery));

    </script>
    

    <script>
        $("#next").click(function(){

        $("#lanjut").attr("href"), function(response) {
           $posts.append($(response).find("#posts").html());
        };
        });
    
    </script>
</body>

</html>
<?php /**PATH D:\web\proudct\resources\views/pages/blog.blade.php ENDPATH**/ ?>