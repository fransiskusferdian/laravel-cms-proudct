

<?php $__env->startPush('after-style'); ?>
    <style>
          .img-wrap {
            position: relative;
            display: inline-block;
        }

        .img-wrap .close {
            position: absolute;
            top: 2px;
            right: 2px;
            z-index: 100;
            background-color: #FFF;
            padding: 5px 5px 5px;
            color: #000;
            font-weight: bold;
            cursor: pointer;
            opacity: .2;
            text-align: center;
            font-size: 18px;
            line-height: 10px;
            border-radius: 50%;
        }

        .img-wrap:hover .close {
            opacity: 1;
        }

    </style>    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<?php if(Session::has('success')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(Session::get('success')); ?>

     </div>
<?php elseif(Session::has('danger')): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e(Session::get('danger')); ?>

     </div> 
<?php endif; ?>
       <!-- Animated -->
            <div class="animated fadeIn gallery-section">
                <div class="row mb-5">
                    <div class="col">
                    <a href="<?php echo e(route('promotion.create')); ?>" class="btn btn-primary">Add Promotion</a>
                    </div>
                </div>
                <div class="row gallery-grid justify-content-center">
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card mr-2" style="width: 18rem;">
                            <img src="<?php echo e(Storage::url($item->image)); ?>" class="card-img-top" alt="">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($item->name); ?></h5>
                                <p class="card-text"><?php echo e($item->position); ?>

                                </p>
                                <a href="" data-href="<?php echo e(route('deleteteam', $item->id)); ?>" class="btn btn-danger" data-toggle="modal"
                                    data-target="#deleteTeamModal"><i class="fa fa-trash"></i>
                                </a>
                                <a href="<?php echo e(route('editteam', $item->id)); ?>" class="btn btn-warning">
                                    <i class="fa fa-pencil"></i>
                                </a>
                            </div>
                        </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>    

                <!-- Delete Image Modal-->
                <div class="modal fade" id="deleteTeamModal" tabindex="-1" role="dialog"
                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <form action="" method="post" id="deleteteam">
                                <div class="modal-header d-flex align-item-start">
                                    <h5 class="modal-title" id="exampleModalLabel">Are you sure to delete Team member?</h5>
                                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                                <div class="modal-body">Are you sure want to delete this Team member?</div>
                                <div class="modal-footer">
                                    <?php echo method_field('delete'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                    <button class="btn btn-primary" type="submit">Delete</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- End Delete Image Modal-->
            </>    

<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>
      <script>
        $('#deleteTeamModal').on('show.bs.modal', function (e) {
            $(this).find('#deleteteam').attr('action', $(e.relatedTarget).data('href'));
        });
      </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web\proudct\resources\views/pages/admin/team/index.blade.php ENDPATH**/ ?>